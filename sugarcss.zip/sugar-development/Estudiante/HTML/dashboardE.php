<?php include '../../HEADERS/headerE.php'; ?>
<!DOCTYPE html>
<html lang="es">
  <head>
      <meta charset="UTF-8" />
      <title>Dashboard Estudiante</title>
  <link rel="stylesheet" href="../../Css/style.css" />
      <!-- Material Icons CDN -->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  </head>
  <body>
    <body class="body-rol estudiante">
    <?php include '../../Estudiante/HTML/bienvenida.php'; ?>
    <?php include '../../PHP/dashboard.php'; ?>
    <script src="../../Direccion/JS/estadisticas.js"></script>
  </body>
</html>
