<?php 
echo "Error: No se pudo conectar a la base de datos.";
?>