<?php include '../../HEADERS/headerAA.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anuncios</title>
        <link rel="stylesheet" href="../../Css/style.css" />
</head>
<div class="anuncio1"></div>
<body class="paganuncios"><div class="flexp">

<div class="anuncio2"></div>
<div class="anuncio3"></div>
</div>
</body>
</html>

