<?php include '../../HEADERS/headerF.php'; ?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <title>Dashboard Funcionario</title>
  <link rel="stylesheet" href="../../Css/style.css" />
  </head>
  <?php include '../../Funcionario/HTML/bienvenida.php'; ?>
  <body>
    <body class="body-rol funcionario">
  <script src="../../Direccion/JS/estadisticas.js"></script>
  <?php include '../../PHP/dashboard.php'; ?>

</body>
</html>