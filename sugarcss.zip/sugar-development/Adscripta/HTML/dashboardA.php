<?php include '../../HEADERS/headerA.php'; ?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <title>Dashboard Adscripta</title>
    <link rel="stylesheet" href="../../Css/style.css" />
  </head>
  <?php include '../../Adscripta/HTML/bienvenida.php'; ?>
  <script src="../../Direccion/JS/estadisticas.js"></script>

  <?php include '../../PHP/dashboard.php'; ?>

</body>
</html>
